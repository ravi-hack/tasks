# Blackjack Game
To run this app:

Make sure Nodejs and MongoDB is installed.
and start mongoDB
```

Open up an additional CMD and navigate to the project folder, install the node modules, and run the command.
```console
$ cd /Blackjack
$ npm install
$ node app.js
```


# Technologies used
Front: Jade, CSS, Javascript

Back/Framework: Nodejs, MongoDB, Express, Jade, client-sessions, bcryptjs
